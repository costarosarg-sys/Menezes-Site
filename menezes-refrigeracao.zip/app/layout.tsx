import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title:
    "Menezes Refrigeração - Instalação e Manutenção de Ar Condicionado | Rio Grande, RS",
  description:
    "Especialistas em instalação, manutenção e reparos de ar condicionado e refrigeração em Rio Grande, RS. Atendimento rápido e profissional. Solicite seu orçamento!",
  keywords: [
    "refrigeração Rio Grande",
    "instalação ar condicionado Rio Grande",
    "manutenção ar condicionado",
    "reparo geladeira",
    "assistência técnica refrigeração",
    "ar condicionado Rio Grande RS",
    "refrigeração comercial",
    "carregamento gás refrigerante",
    "Menezes Refrigeração",
  ],
  authors: [{ name: "Menezes Refrigeração" }],
  creator: "Menezes Refrigeração",
  publisher: "Menezes Refrigeração",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL("https://menezes-refrigeracao.vercel.app"),
  alternates: {
    canonical: "/",
  },
  openGraph: {
    title: "Menezes Refrigeração - Instalação e Manutenção de Ar Condicionado",
    description:
      "Especialistas em instalação, manutenção e reparos de ar condicionado e refrigeração em Rio Grande, RS. Atendimento rápido e profissional.",
    url: "https://menezes-refrigeracao.vercel.app",
    siteName: "Menezes Refrigeração",
    locale: "pt_BR",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Menezes Refrigeração - Instalação e Manutenção de Ar Condicionado",
    description:
      "Especialistas em instalação, manutenção e reparos de ar condicionado e refrigeração em Rio Grande, RS.",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  verification: {
    // Adicione códigos de verificação quando disponíveis
    // google: "seu-codigo-google",
    // yandex: "seu-codigo-yandex",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
