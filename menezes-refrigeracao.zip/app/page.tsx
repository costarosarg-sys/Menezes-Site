import {
  AirVent,
  Cylinder,
  Lightbulb,
  Refrigerator,
  Settings,
  Snowflake,
  Wrench,
} from "lucide-react";
import Image from "next/image";

// Structured Data para SEO
const structuredData = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  name: "Menezes Refrigeração",
  description:
    "Especialistas em instalação, manutenção e reparos de ar condicionado e refrigeração em Rio Grande, RS",
  address: {
    "@type": "PostalAddress",
    addressLocality: "Rio Grande",
    addressRegion: "RS",
    addressCountry: "BR",
  },
  areaServed: {
    "@type": "City",
    name: "Rio Grande",
  },
  serviceType: [
    "Instalação de Ar Condicionado",
    "Manutenção Preventiva",
    "Reparos e Assistência Técnica",
    "Refrigeração Comercial",
    "Carregamento de Gás",
    "Consultoria Técnica",
  ],
  priceRange: "$$",
};

export default function Home() {
  const whatsappNumber = "5553991299960"; // (53) 99129-9960
  const email = "menezesclimarefri@gmail.com";
  const whatsappMessage = encodeURIComponent(
    "Olá! Gostaria de solicitar um orçamento para serviços de refrigeração."
  );
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${whatsappMessage}`;

  return (
    <>
      {/* Structured Data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
      />

      {/* Skip to main content link para acessibilidade */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:rounded-md focus:bg-blue-600 focus:px-4 focus:py-2 focus:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
      >
        Pular para o conteúdo principal
      </a>

      <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
        {/* Hero Section */}
        <header
          role="banner"
          className="relative overflow-hidden bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 text-white"
        >
          <div
            className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDM0YzAtMS4xLS45LTItMi0ySDI2Yy0xLjEgMC0yIC45LTIgMnYyNGMwIDEuMS45IDIgMiAyaDhjMS4xIDAgMi0uOSAyLTJWMzR6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-10"
            aria-hidden="true"
          ></div>

          <div className="relative mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20 lg:px-8 lg:py-28">
            <div className="text-center" id="main-content">
              <h1 className="flex items-center justify-center gap-3 text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl lg:text-7xl">
                <span>Menezes</span>
                <Snowflake className="h-8 w-8 text-blue-200 sm:h-10 sm:w-10 md:h-12 md:w-12 lg:h-14 lg:w-14" aria-hidden="true" />
          </h1>
              <p className="mt-2 text-lg font-normal text-blue-100 sm:text-xl md:text-2xl lg:text-3xl">
                CLIMATIZAÇÃO E REFRIGERAÇÃO
              </p>
              <p className="mx-auto mt-6 max-w-3xl text-xl text-blue-100 sm:text-2xl">
                Especialistas em{" "}
                <span className="font-bold text-white underline decoration-2 underline-offset-4">
                  Instalação de Ar Condicionado
                </span>
                ,{" "}
                <span className="font-bold text-white underline decoration-2 underline-offset-4">
                  Manutenção
                </span>{" "}
                e{" "}
                <span className="font-bold text-white underline decoration-2 underline-offset-4">
                  Reparos
                </span>{" "}
                de Refrigeração
              </p>
              <div className="mx-auto mt-6 flex items-center justify-center gap-2 text-xl font-bold text-white sm:text-2xl lg:text-3xl">
                <svg
                  className="h-6 w-6 flex-shrink-0 sm:h-8 sm:w-8"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                  />
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                  />
                </svg>
                <span className="bg-white/20 px-3 py-2 rounded-lg backdrop-blur-sm sm:px-4">
                  Rio Grande, RS
                </span>
              </div>

              {/* CTA Principal - MAIOR */}
              <nav
                aria-label="Ações principais"
                className="mt-10 flex flex-col items-center justify-center gap-4 sm:mt-12 sm:flex-row"
              >
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Fale conosco no WhatsApp - Abre em nova aba"
                  className="group flex items-center gap-3 rounded-full bg-green-500 px-8 py-5 text-lg font-bold text-white shadow-2xl transition-all hover:bg-green-600 hover:shadow-green-500/50 hover:scale-110 focus:outline-none focus:ring-4 focus:ring-green-300 focus:ring-offset-2 focus:ring-offset-blue-800 sm:gap-4 sm:px-12 sm:py-6 sm:text-2xl"
                >
                  <svg
                    className="h-6 w-6 sm:h-8 sm:w-8"
                    fill="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                    aria-hidden="true"
                  >
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
                  </svg>
                  <span>Fale Conosco no WhatsApp</span>
                </a>
                <a
                  href="#servicos"
                  aria-label="Ir para seção de serviços"
                  className="rounded-full border-2 border-white px-6 py-4 text-base font-semibold text-white transition-all hover:bg-white hover:text-blue-700 focus:outline-none focus:ring-4 focus:ring-white/50 focus:ring-offset-2 focus:ring-offset-blue-800 sm:px-8 sm:text-lg"
                >
                  Nossos Serviços
                </a>
              </nav>
            </div>
          </div>
        </header>

        {/* Serviços Section */}
        <section
          id="servicos"
          aria-labelledby="servicos-heading"
          className="py-16 sm:py-20 lg:py-24"
        >
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h2
                id="servicos-heading"
                className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl"
              >
                Nossos Serviços
              </h2>
              <p className="mx-auto mt-4 max-w-2xl text-lg text-gray-600">
                Soluções completas em refrigeração e climatização para sua casa
                ou empresa em{" "}
                <span className="font-bold text-blue-700">Rio Grande, RS</span>
              </p>
            </div>

            <div
              className="mt-12 grid gap-6 sm:mt-16 sm:grid-cols-2 sm:gap-8 lg:grid-cols-3"
              role="list"
            >
              {/* Instalação */}
              <article
                className="rounded-xl bg-white p-6 shadow-lg transition-all hover:shadow-xl hover:-translate-y-1 sm:p-8"
                role="listitem"
              >
                <div className="flex h-32 w-full items-center justify-center rounded-lg bg-gradient-to-br from-blue-50 to-blue-100">
                  <AirVent
                    className="h-20 w-20 text-blue-600 sm:h-24 sm:w-24"
                    aria-hidden="true"
                  />
                </div>
                <h3 className="mt-6 text-lg font-semibold text-gray-900 sm:text-xl">
                  Instalação de Ar Condicionado
                </h3>
                <p className="mt-2 text-sm text-gray-600 sm:text-base">
                  Instalação profissional de ar condicionado split, janela,
                  piso-teto e sistemas centralizados. Garantimos instalação
                  adequada para máximo desempenho.
                </p>
              </article>

              {/* Manutenção */}
              <article
                className="rounded-xl bg-white p-6 shadow-lg transition-all hover:shadow-xl hover:-translate-y-1 sm:p-8"
                role="listitem"
              >
                <div className="flex h-32 w-full items-center justify-center rounded-lg bg-gradient-to-br from-green-50 to-green-100">
                  <Settings
                    className="h-20 w-20 text-green-600 sm:h-24 sm:w-24"
                    aria-hidden="true"
                  />
                </div>
                <h3 className="mt-6 text-lg font-semibold text-gray-900 sm:text-xl">
                  Manutenção Preventiva
                </h3>
                <p className="mt-2 text-sm text-gray-600 sm:text-base">
                  Limpeza, higienização e manutenção periódica para garantir
                  eficiência energética e prolongar a vida útil do seu
                  equipamento.
                </p>
              </article>

              {/* Reparos */}
              <article
                className="rounded-xl bg-white p-6 shadow-lg transition-all hover:shadow-xl hover:-translate-y-1 sm:p-8"
                role="listitem"
              >
                <div className="flex h-32 w-full items-center justify-center rounded-lg bg-gradient-to-br from-red-50 to-red-100">
                  <Wrench
                    className="h-20 w-20 text-red-600 sm:h-24 sm:w-24"
                    aria-hidden="true"
                  />
                </div>
                <h3 className="mt-6 text-lg font-semibold text-gray-900 sm:text-xl">
                  Reparos e Assistência Técnica
                </h3>
                <p className="mt-2 text-sm text-gray-600 sm:text-base">
                  Diagnóstico rápido e reparos eficientes. Atendimento de
                  emergência para resolver problemas urgentes com agilidade.
                </p>
              </article>

              {/* Refrigeração Comercial */}
              <article
                className="rounded-xl bg-white p-6 shadow-lg transition-all hover:shadow-xl hover:-translate-y-1 sm:p-8"
                role="listitem"
              >
                <div className="flex h-32 w-full items-center justify-center rounded-lg bg-gradient-to-br from-purple-50 to-purple-100">
                  <Refrigerator
                    className="h-20 w-20 text-purple-600 sm:h-24 sm:w-24"
                    aria-hidden="true"
                  />
                </div>
                <h3 className="mt-6 text-lg font-semibold text-gray-900 sm:text-xl">
                  Refrigeração Comercial
                </h3>
                <p className="mt-2 text-sm text-gray-600 sm:text-base">
                  Soluções para comércios, restaurantes e empresas. Câmaras
                  frias, freezers, balcões refrigerados e muito mais.
                </p>
              </article>

              {/* Carregamento de Gás */}
              <article
                className="rounded-xl bg-white p-6 shadow-lg transition-all hover:shadow-xl hover:-translate-y-1 sm:p-8"
                role="listitem"
              >
                <div className="flex h-32 w-full items-center justify-center rounded-lg bg-gradient-to-br from-yellow-50 to-yellow-100">
                  <Cylinder
                    className="h-20 w-20 text-yellow-600 sm:h-24 sm:w-24"
                    aria-hidden="true"
                  />
                </div>
                <h3 className="mt-6 text-lg font-semibold text-gray-900 sm:text-xl">
                  Carregamento de Gás
                </h3>
                <p className="mt-2 text-sm text-gray-600 sm:text-base">
                  Recarga de gás refrigerante com produtos de qualidade e
                  procedimentos seguros, seguindo todas as normas técnicas.
                </p>
              </article>

              {/* Consultoria */}
              <article
                className="rounded-xl bg-white p-6 shadow-lg transition-all hover:shadow-xl hover:-translate-y-1 sm:p-8"
                role="listitem"
              >
                <div className="flex h-32 w-full items-center justify-center rounded-lg bg-gradient-to-br from-indigo-50 to-indigo-100">
                  <Lightbulb
                    className="h-20 w-20 text-indigo-600 sm:h-24 sm:w-24"
                    aria-hidden="true"
                  />
                </div>
                <h3 className="mt-6 text-lg font-semibold text-gray-900 sm:text-xl">
                  Consultoria Técnica
                </h3>
                <p className="mt-2 text-sm text-gray-600 sm:text-base">
                  Orientação profissional para escolha do melhor equipamento e
                  sistema de climatização para suas necessidades.
                </p>
              </article>
            </div>

            {/* CTA na seção de serviços */}
            <div className="mt-10 text-center sm:mt-12">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Solicitar orçamento via WhatsApp - Abre em nova aba"
                className="inline-flex items-center gap-2 rounded-full bg-green-500 px-6 py-3 text-base font-semibold text-white shadow-lg transition-all hover:bg-green-600 hover:shadow-xl focus:outline-none focus:ring-4 focus:ring-green-300 focus:ring-offset-2 sm:px-8 sm:py-4 sm:text-lg"
              >
                <svg
                  className="h-5 w-5"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                  aria-hidden="true"
                >
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
                </svg>
                Solicitar Orçamento Agora
              </a>
            </div>
          </div>
        </section>

        {/* Seção de Equipamentos */}
        <section
          aria-labelledby="equipamentos-heading"
          className="bg-gradient-to-b from-white to-gray-50 py-16 sm:py-20 lg:py-24"
        >
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h2
                id="equipamentos-heading"
                className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl"
              >
                Equipamentos que Trabalhamos
              </h2>
              <p className="mx-auto mt-4 max-w-2xl text-lg text-gray-600">
                Especialistas em diversos tipos de equipamentos de refrigeração
                e climatização
              </p>
            </div>

            <div
              className="mt-12 grid gap-8 sm:mt-16 sm:grid-cols-2 sm:gap-12 lg:grid-cols-3 lg:gap-8"
              role="list"
            >
              {/* Ar Condicionado */}
              <article
                className="flex flex-col items-center text-center"
                role="listitem"
              >
                <div className="group relative h-64 w-full max-w-md overflow-hidden rounded-2xl bg-gradient-to-br from-blue-50 to-blue-100 p-6 shadow-lg transition-all duration-300 hover:shadow-xl sm:h-80 sm:p-8">
                  <Image
                    src="/ar-condicionado.png"
                    alt="Ar condicionado split instalado na parede"
                    width={400}
                    height={400}
                    className="h-full w-full object-contain transition-transform duration-300 group-hover:scale-110"
                    loading="lazy"
                  />
                </div>
                <h3 className="mt-6 text-xl font-semibold text-gray-900 sm:text-2xl">
                  Ar Condicionado
                </h3>
                <p className="mt-2 text-sm text-gray-600 sm:text-base">
                  Instalação, manutenção e reparos em todos os modelos
                </p>
              </article>

              {/* Geladeira */}
              <article
                className="flex flex-col items-center text-center"
                role="listitem"
              >
                <div className="group relative h-64 w-full max-w-md overflow-hidden rounded-2xl bg-gradient-to-br from-purple-50 to-purple-100 p-6 shadow-lg transition-all duration-300 hover:shadow-xl sm:h-80 sm:p-8">
                  <Image
                    src="/geladeira.png"
                    alt="Geladeira residencial e comercial"
                    width={400}
                    height={400}
                    className="h-full w-full object-contain transition-transform duration-300 group-hover:scale-110"
                    loading="lazy"
                  />
                </div>
                <h3 className="mt-6 text-xl font-semibold text-gray-900 sm:text-2xl">
                  Geladeira e Refrigeração
                </h3>
                <p className="mt-2 text-sm text-gray-600 sm:text-base">
                  Soluções completas para refrigeração comercial e residencial
                </p>
              </article>

              {/* Freezer */}
              <article
                className="flex flex-col items-center text-center sm:col-span-2 lg:col-span-1"
                role="listitem"
              >
                <div className="group relative h-64 w-full max-w-md overflow-hidden rounded-2xl bg-gradient-to-br from-cyan-50 to-cyan-100 p-6 shadow-lg transition-all duration-300 hover:shadow-xl sm:h-80 sm:p-8">
                  <Image
                    src="/freez.png"
                    alt="Freezer vertical e horizontal para uso comercial e residencial"
                    width={400}
                    height={400}
                    className="h-full w-full object-contain transition-transform duration-300 group-hover:scale-110"
                    loading="lazy"
                  />
                </div>
                <h3 className="mt-6 text-xl font-semibold text-gray-900 sm:text-2xl">
                  Freezer
                </h3>
                <p className="mt-2 text-sm text-gray-600 sm:text-base">
                  Freezers verticais, horizontais e comerciais. Manutenção e
                  reparos especializados
                </p>
              </article>
            </div>

            {/* CTA na seção de equipamentos */}
            <div className="mt-10 text-center sm:mt-12">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Solicite seu orçamento via WhatsApp - Abre em nova aba"
                className="inline-flex items-center gap-2 rounded-full bg-green-500 px-6 py-3 text-base font-semibold text-white shadow-lg transition-all hover:bg-green-600 hover:shadow-xl focus:outline-none focus:ring-4 focus:ring-green-300 focus:ring-offset-2 sm:px-8 sm:py-4 sm:text-lg"
              >
                <svg
                  className="h-5 w-5"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                  aria-hidden="true"
                >
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
                </svg>
                Solicite seu Orçamento
              </a>
            </div>
          </div>
        </section>

        {/* Benefícios Section */}
        <section
          aria-labelledby="beneficios-heading"
          className="bg-gray-50 py-16 sm:py-20 lg:py-24"
        >
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h2
                id="beneficios-heading"
                className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl"
              >
                Por Que Escolher a Menezes Refrigeração?
              </h2>
              <p className="mx-auto mt-4 max-w-2xl text-lg text-gray-600">
                Profissionalismo, qualidade e compromisso com seu conforto
              </p>
            </div>

            <div
              className="mt-12 grid gap-8 sm:mt-16 md:grid-cols-2 lg:grid-cols-4"
              role="list"
            >
              <div className="text-center" role="listitem">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-blue-100">
                  <svg
                    className="h-8 w-8 text-blue-600"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <h3 className="mt-6 text-lg font-semibold text-gray-900">
                  Profissionais Certificados
                </h3>
                <p className="mt-2 text-gray-600">
                  Técnicos qualificados e experientes em todas as áreas de
                  refrigeração
                </p>
              </div>

              <div className="text-center" role="listitem">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
                  <svg
                    className="h-8 w-8 text-green-600"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <h3 className="mt-6 text-lg font-semibold text-gray-900">
                  Atendimento Rápido
                </h3>
                <p className="mt-2 text-gray-600">
                  Resposta ágil e atendimento de emergência quando você mais
                  precisa
                </p>
              </div>

              <div className="text-center" role="listitem">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-yellow-100">
                  <svg
                    className="h-8 w-8 text-yellow-600"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                    />
                  </svg>
                </div>
                <h3 className="mt-6 text-lg font-semibold text-gray-900">
                  Garantia nos Serviços
                </h3>
                <p className="mt-2 text-gray-600">
                  Trabalhamos com garantia para sua tranquilidade e satisfação
                </p>
              </div>

              <div className="text-center" role="listitem">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-purple-100">
                  <svg
                    className="h-8 w-8 text-purple-600"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <h3 className="mt-6 text-lg font-semibold text-gray-900">
                  Preços Justos
                </h3>
                <p className="mt-2 text-gray-600">
                  Orçamentos transparentes e competitivos, sem surpresas
          </p>
        </div>
            </div>
          </div>
        </section>

        {/* Localização Section */}
        <section
          aria-labelledby="localizacao-heading"
          className="py-16 sm:py-20 lg:py-24"
        >
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="rounded-2xl bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-10 text-center text-white shadow-xl sm:px-8 sm:py-12">
              <div className="mb-4 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <svg
                  className="h-8 w-8 flex-shrink-0"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                  />
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                  />
                </svg>
                <h2
                  id="localizacao-heading"
                  className="text-3xl font-bold sm:text-4xl lg:text-5xl"
                >
                  Atendemos em{" "}
                  <span className="block bg-white/20 px-3 py-2 mt-2 rounded-lg backdrop-blur-sm sm:inline-block sm:mt-0 sm:px-4">
                    Rio Grande, RS
                  </span>
                </h2>
              </div>
              <p className="mx-auto mt-4 max-w-2xl text-lg text-blue-100 sm:text-xl">
                Estamos prontos para atender sua necessidade de refrigeração e
                climatização em toda a região
              </p>
              <div className="mt-8">
                <a
                  href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
                  aria-label="Entre em contato agora via WhatsApp - Abre em nova aba"
                  className="inline-flex items-center gap-3 rounded-full bg-white px-6 py-3 text-base font-semibold text-blue-700 shadow-lg transition-all hover:bg-blue-50 hover:scale-105 focus:outline-none focus:ring-4 focus:ring-white/50 focus:ring-offset-2 focus:ring-offset-blue-700 sm:px-8 sm:py-4 sm:text-lg"
                >
                  <svg
                    className="h-5 w-5 sm:h-6 sm:w-6"
                    fill="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                    aria-hidden="true"
                  >
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
                  </svg>
                  Entre em Contato Agora
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer role="contentinfo" className="bg-gray-900 text-gray-300">
          <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-12 lg:px-8">
            <div className="text-center">
              <h3 className="flex items-center justify-center gap-2 text-xl font-bold text-white sm:text-2xl">
                <span>Menezes</span>
                <Snowflake className="h-5 w-5 text-blue-300 sm:h-6 sm:w-6" aria-hidden="true" />
              </h3>
              <p className="mt-1 text-sm font-normal text-gray-300 sm:text-base">
                CLIMATIZAÇÃO E REFRIGERAÇÃO
              </p>
              <p className="mt-4 text-base sm:text-lg">
                Instalação, Manutenção e Reparos de Ar Condicionado
              </p>
              <div className="mt-3 flex items-center justify-center gap-2">
                <svg
                  className="h-5 w-5 text-gray-400"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                  />
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                  />
                </svg>
                <p className="text-xl font-semibold text-white">
                  Rio Grande, RS
                </p>
              </div>

              <div className="mt-6 flex flex-col items-center gap-4 sm:mt-8 sm:flex-row sm:justify-center">
                <a
                  href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
                  aria-label="Contato via WhatsApp - Abre em nova aba"
                  className="inline-flex items-center gap-2 rounded-full bg-green-500 px-5 py-2.5 text-sm font-semibold text-white transition-all hover:bg-green-600 focus:outline-none focus:ring-4 focus:ring-green-300 focus:ring-offset-2 focus:ring-offset-gray-900 sm:px-6 sm:py-3 sm:text-base"
                >
                  <svg
                    className="h-5 w-5"
                    fill="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                    aria-hidden="true"
                  >
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
                  </svg>
                  WhatsApp: (53) 99129-9960
                </a>
                <a
                  href={`mailto:${email}`}
                  aria-label="Enviar email"
                  className="inline-flex items-center gap-2 rounded-full border-2 border-gray-600 px-5 py-2.5 text-sm font-semibold text-gray-300 transition-all hover:border-gray-400 hover:text-white focus:outline-none focus:ring-4 focus:ring-gray-600 focus:ring-offset-2 focus:ring-offset-gray-900 sm:px-6 sm:py-3 sm:text-base"
                >
                  <svg
                    className="h-5 w-5"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                    />
                  </svg>
                  {email}
          </a>
        </div>

              <p className="mt-6 text-xs text-gray-400 sm:mt-8 sm:text-sm">
                © {new Date().getFullYear()} Menezes Climatização e Refrigeração. Todos os
                direitos reservados.
              </p>
            </div>
          </div>
        </footer>
    </div>
    </>
  );
}
